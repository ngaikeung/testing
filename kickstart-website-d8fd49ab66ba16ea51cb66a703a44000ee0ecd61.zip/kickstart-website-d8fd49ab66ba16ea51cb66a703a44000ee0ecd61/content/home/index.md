+++
# Homepage
type = "widget_page"
headless = true  # Homepage is headless, other widget pages are not.
+++
